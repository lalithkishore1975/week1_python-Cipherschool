a=input()
print(a)
type(a)

c=input()
b=input()
print(b)
print(c)

int a=65
char b= (char)a

bin(65)

#typrecoercion

a=15
str(a)

d=int('1234')

float('1.5')


a=65
isinstance(a,object)
a="A"
isinstance(a,object)
