print("Anuj Verma")
print?
print(1,2,3,"anuj",3.4,1+5j,sep=",")
print("Hello,end=!")
print("World")
print("a",end=")")
print("b")
print("c")
print(1,2,3,4,5,6)