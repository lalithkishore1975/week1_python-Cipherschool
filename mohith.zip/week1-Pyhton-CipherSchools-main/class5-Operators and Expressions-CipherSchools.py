sum(1,2)
5+5
10-5
10/3
10//3
isinstance(10.5,int)
10/2
10%3
2**3
2*3
"anuj"+"verma"
"abc"*3
1==2
1!= 2
"a"<'A'
True and False

True and 1

1 and 0
1 and 5
ininstance(True,int)
type(True)


1.5 or ""

"" or 2.5

bool("")
bool([1,2,3])

"" and 0

112 and ""


Short Circuitng

a or b = a (if a is truthy)
a or b = b (if a is falsy)
a and b = b (is a is truthy)
a and b = a (if a is falsy)

trur or b = True
false or b= b
true and b = b
false and b = false