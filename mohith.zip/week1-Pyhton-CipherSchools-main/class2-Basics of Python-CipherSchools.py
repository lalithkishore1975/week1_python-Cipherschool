"""
this is a comment
"""
# This is a comment

print("Hello world")

a="a"
type(a)

isinstance(a,str)
isinstance(a,int)
isinstance(print,object)

print(hex(id(a)))

a='2255151515151515151'
print(id(a))

a='hbhbh'
print(id(a))
